select NAME, CONCAT(SUBSTR(NAME,1,3), SUBSTR(PHNO,1,3)) as password
from USERS
order by NAME;