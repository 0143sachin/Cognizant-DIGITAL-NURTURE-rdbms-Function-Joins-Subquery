select resortID,SUM(bedroomcount) as TotalRoom, SUM(sleepcapacity) as Capacity
from Cabin
group by resortID
having SUM(bedroomcount)>=60 and SUM(sleepcapacity)>=100
order by resortID;