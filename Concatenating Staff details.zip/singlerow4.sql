select CONCAT(staff_id, SUBSTR(staff_name,1,3)) as official_mail
from Staff 
order by official_mail;