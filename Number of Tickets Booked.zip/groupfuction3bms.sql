select USER_ID, COUNT(NO_SEATS) as no_of_tickets 
from TICKETS
group by USER_ID
order by no_of_tickets;