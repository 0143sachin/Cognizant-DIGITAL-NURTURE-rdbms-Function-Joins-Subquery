select Length(comments) as COMMENTS_LENGTH
from Review 
group by comments
order by COMMENTS_LENGTH;