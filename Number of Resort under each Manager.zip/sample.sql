select managerID, COUNT(resortID) as NUMBEROFRESORT 
from Resort
where starRating>=4
group by managerID
order by managerID;