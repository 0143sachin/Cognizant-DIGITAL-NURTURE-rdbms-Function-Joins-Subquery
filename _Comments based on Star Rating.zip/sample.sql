select resortID, resortName,
case 
WHEN (starRating <= 5.0 and starRating >= 4.5) THEN 'Excellent Resort'
WHEN (starRating <= 4.4 and starRating >= 4.0) THEN 'Very Good Resort'
ELSE 'Good Resort'
END Comments 
from Resort;