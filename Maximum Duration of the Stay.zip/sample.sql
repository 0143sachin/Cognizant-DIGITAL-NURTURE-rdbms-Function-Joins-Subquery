select MAX(todate-fromdate) as MAXIMUMDAYS 
from Booking;