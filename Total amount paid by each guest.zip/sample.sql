select resortID, guestid, sum(totalcharge) as TotalCost
from Booking
group by resortID, guestid
order by resortID,guestid;