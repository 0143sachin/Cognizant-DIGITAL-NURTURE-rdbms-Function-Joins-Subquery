select resortID, SUM(bedroomcount) as TOTALCOUNT 
from Cabin
group by resortID
order by resortID;